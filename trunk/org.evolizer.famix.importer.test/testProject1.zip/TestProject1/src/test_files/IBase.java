/**
 * 
 */
package test_files;

/**
 * @author pinzger
 *
 */
public interface IBase {
	public int compute();
}
