package test_files;


public class Sum extends Base {
	public Sum() {
		super();
	}
	public Sum(int a, int b) {
		super(a, b);
	}
	public int compute() {
		return getA() + getB();
	}
}
