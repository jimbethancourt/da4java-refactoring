/**
 * 
 */
package test_files;

import java.util.Vector;

/**
 * @author pinzger
 *
 */
public class Variables {
	private int field;
	private int fMulti1, fMulti2, fMulti3;
	private int fInit = 4;

	private int a,b,c=2;
	private static final String st = "static string";
	
	private Sum refSum;
	private Vector<Sum> containerSum = new Vector<Sum>();
	private Sum[] arraySum;

	
	public void m(int param, int[] arrayParam) {
		int local;
		int multi1, multi2;

		String localVariableExpression = "a String";
		try {
			int nrs[] = {1,2,3,4,5};
			for (int inFor=0; inFor < 10; inFor++) {
				int value = nrs[inFor];
			}
		} catch (ArrayIndexOutOfBoundsException aiob) {
			System.err.println("Some error");
		}
	} 
}
